# string-utils

Simple string utility functions for Node.js.

## Functions

### reverseString(str)
Reverses the input string.

### capitalize(str)
Capitalizes the first letter of the string.

## Usage

```js
const { reverseString, capitalize } = require('string-utils');

console.log(reverseString('hello')); // 'olleh'
console.log(capitalize('world'));    // 'World'
