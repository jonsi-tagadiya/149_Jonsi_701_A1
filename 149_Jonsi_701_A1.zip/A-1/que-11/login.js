const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function askQuestion(query) {
  return new Promise(resolve => rl.question(query, resolve));
}

async function login() {
  try {
    const username = await askQuestion('Enter your username: ');
    const password = await askQuestion('Enter your password: ');
    const email = await askQuestion('Enter your email: ');

    console.log('\n--- Your login info ---');
    console.log(`Username: ${username}`);
    console.log(`Password: ${'*'.repeat(password.length)}`);  // Mask password length
    console.log(`Email: ${email}`);

    // Here you can add validation or authentication logic

  } catch (err) {
    console.error('Error:', err);
  } finally {
    rl.close();
  }
}

login();
