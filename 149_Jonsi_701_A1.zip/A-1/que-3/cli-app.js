// cliApp.js

const readline = require('readline');
const Chatbot = require('./chatbot'); // Import the Chatbot class

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const bot = new Chatbot(); // Create an instance of the Chatbot

function promptUser() {
  rl.question('You: ', (input) => {
    const response = bot.getReply(input);
    console.log(`Bot: ${response}`);
    promptUser();
  });
}

promptUser();