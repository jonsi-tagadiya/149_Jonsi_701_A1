// chatbot.js

/**
 * Chatbot class to handle responses based on user messages.
 */
class Chatbot {
  constructor() {
    this.Bot_Age = 25;
    this.Bot_Name = "name1";
    this.Bot_University = "VNSGU";
    this.Bot_Country = "India";
  }

  /**
   * Generates a response based on the user's message.
   * @param {string} message - The user's message.
   * @returns {string} - The chatbot's response.
   */
  getReply(message) {
    message = message.toLowerCase();

    if (message.includes("hi") || message.includes("hello") || message.includes("welcome")) {
      return "Hi!";
    } else if (message.includes("your") && message.includes("age")) {
      return `I'm ${this.Bot_Age} years old.`;
    } else if (message.includes("how") && message.includes("are") && message.includes("you")) {
      return "I'm fine ^_^";
    } else if (message.includes("where") && message.includes("live") && message.includes("you")) {
      return `I live in ${this.Bot_Country}.`;
    } else {
      return "Sorry, I didn't get it :(";
    }
  }
}

module.exports = Chatbot;
