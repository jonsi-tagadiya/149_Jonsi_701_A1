// Define a global variable
global.appName = "Asss-1";

// Define an object representing a user
const user = {
  name: "Jenny",
  age: 23,
  greet() {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
  }
};

// Access and print the global variable
console.log("Application Name (global):", global.appName);

// Use the object and call its method
user.greet();

// Modify the global variable
global.appName = "Assignment-1";
console.log("Updated Application Name (global):", global.appName);




// // Using console to log messages
// console.log("Hello, Node.js!");

// // Using process to get environment variables
// console.log("Node.js Version:", process.version);
// console.log("Current Directory:", process.cwd());

// // Using setTimeout to delay execution
// setTimeout(() => {
//   console.log("This message is displayed after 2 seconds.");
// }, 2000);

// // Using setInterval to repeat execution
// let count = 0;
// const intervalId = setInterval(() => {
//   console.log("This message is displayed every 3 seconds.");
//   count++;
//   if (count === 3) {
//     clearInterval(intervalId); // Stop after 3 repetitions
//     console.log("Interval cleared.");
//   }
// }, 3000);

// // Using Buffer to handle binary data
// const buffer = Buffer.from("Hello, Buffer!");
// console.log("Buffer Content:", buffer.toString());

// // Using global object to define a global variable
// global.appName = "MyNodeApp";
// console.log("Global App Name:", appName);
