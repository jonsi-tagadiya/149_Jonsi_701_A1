function sayHi() {
  alert('Hello from static JavaScript!');
}
