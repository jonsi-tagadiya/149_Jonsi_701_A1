// extractor.js
const fs = require('fs');
const unzipper = require('unzipper');
const path = require('path');

// Define input zip file and output directory
const zipFilePath = path.join(__dirname, 'q4.zip');         
const outputFolder = path.join(__dirname, 'q4-folder');     // Output folder

// Ensure output folder exists
if (!fs.existsSync(outputFolder)) {
  fs.mkdirSync(outputFolder);
}

// Extract the zip file
fs.createReadStream(zipFilePath)
  .pipe(unzipper.Extract({ path: outputFolder }))
  .on('close', () => {
    console.log('✅ Extraction complete!');
  })
  .on('error', (err) => {
    console.error('❌ Error during extraction:', err);
  });
