const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'text.txt');
const copyPath = path.join(__dirname, 'text-copy.txt');

// 1. Write data to a file
fs.writeFile(filePath, 'Hello, this is sample text!', (err) => {
  if (err) return console.error('writeFile error:', err);
  console.log('File written successfully.');

  // 2. Read data from the file
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) return console.error('readFile error:', err);
    console.log('File content:', data);

    // 3. Append data to the file
    fs.appendFile(filePath, '\nAppending new line.', (err) => {
      if (err) return console.error('appendFile error:', err);
      console.log('Data appended.');

      // 4. Rename the file
      const newFilePath = path.join(__dirname, 'renamed-sample.txt');
      fs.rename(filePath, newFilePath, (err) => {
        if (err) return console.error('rename error:', err);
        console.log('File renamed.');

        // 5. Copy the file
        fs.copyFile(newFilePath, copyPath, (err) => {
          if (err) return console.error('copyFile error:', err);
          console.log('File copied.');

          // 6. Delete the original renamed file
          fs.unlink(newFilePath, (err) => {
            if (err) return console.error('unlink error:', err);
            console.log('Original renamed file deleted.');

            // 7. Check if copied file exists and get stats
            fs.stat(copyPath, (err, stats) => {
              if (err) return console.error('stat error:', err);
              console.log('Copied file stats:', stats);

              // 8. Read directory contents
              fs.readdir(__dirname, (err, files) => {
                if (err) return console.error('readdir error:', err);
                console.log('Directory files:', files);
              });
            });
          });
        });
      });
    });
  });
});
